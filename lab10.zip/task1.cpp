#include <iostream>
#include<random>
#include<stdlib.h>
#include<time.h>
using namespace std;

int main()
{   int num,n=0,index;
cout<<"ENTER A NUMBER within 100: ";
cin>>num;
srand(time(0));
    int A[20]={};
    cout<< "{ ";
    for(int i=0;i<=20-1;i++){
        A[i]=rand()%100;

    if(A[i]== num ){
        n=n+1;
        index=i;
    }
cout <<A[i]<<" ";
    }cout<<"}\n";
if(n>=1){
    cout<<"THE NUMBER IS  in array at "<< index ;
}
else{
     cout<<"THE NUMBER IS not in array";
}
    return 0;
}
