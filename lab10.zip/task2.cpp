#include <iostream>

using namespace std;
void primecheck(int A[10]){
    int z=0;
    for(int i=0;i<10;i++){
        for(int j=1;j<= A[i];j++){
            if(A[i]%j==0){
               z=z+1;
            }

        }
        if(z==2)
        {

            cout<<"prim: "<<i<<endl;
        }
        z=0;
    }

}

int main()
{
    int A[10];
    int num;
    cout<<"ENTER 10  NUMBERS : ";
    for(int i=0;i<10;i++){
        cin>>num;
        A[i]=num;

    }
           primecheck(A);



    return 0;
}
