#include <iostream>
#include<time.h>
#include<stdlib.h>
#include<random>
using namespace std;
void shufle(int & a,int &b){
int c;
c=a;
a=b;
b=c;
}
void not_shufle(int & a,int &b){
a=a;
b=b;
}
void compare(int A[20] ){
int z=0;
while(z<19){
for(int i=0;i<19;i++){
if(A[z]>A[i+1]){
    shufle(A[z],A[i+1]);}
   else{
    not_shufle(A[z],A[i+1]);
   }
}
z+=1;
}

}

int main()
{
    srand(time(0));
    int A[20];
    cout<<" BEFORE SORTING: "<<endl;
    for(int i=0;i<20;i++){
      A[i]=rand()%100;
      cout<<A[i]<<" ";
    }
    compare(A);
    cout<<"\n AFTER SORTING: "<<endl;
    for(int i=0;i<20;i++){
      cout<<A[i]<<" ";
      }
    return 0;
}
