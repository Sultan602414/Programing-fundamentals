#include <iostream>
#include<windows.h>
#include<math.h>
#include<conio.h>
using namespace std;
void sleep(int m){
for(int j=0;j<m*1300;j++){
}
}
void gotoRowCol(int rpos,int cpos){
int xpos=cpos,ypos=rpos;
COORD scrn;
HANDLE hOuput=GetStdHandle(STD_OUTPUT_HANDLE);
scrn.X=cpos;
scrn.Y=rpos;
SetConsoleCursorPosition(hOuput,scrn);
}

void circle(int radius,int r,int c,char chr){
double Q=1;

for(int i=Q ;i<=360;i++){
double x ,y;
x=radius*cos(3.14*2*Q/360) + r;
y=radius*sin(3.14*2*Q/360 )+ c ;
gotoRowCol(x,y);
cout<<chr;
Q++;
}
}
void uper_wave(int radius,int c,char chr){

 double Q=-90;
 double x ,y;
while(Q>=-271){

    x=radius*cos(2*3.14*Q/360)+15;
	y=radius*sin(2*3.14*Q/360)+c;

		gotoRowCol(x,y);
		cout<<chr;
		sleep(500);
		Q--;
	}


}

void lower_wave(int radius,int c,char chr){
 double Q=270;
while(Q!=450){
double x ,y;
x=radius*cos(3.14*2*Q/360) + 15;
y=radius*sin(3.14*2*Q/360 )+ c ;
gotoRowCol(x,y);
cout<<chr;
sleep(500);
Q++;
}
}

void line(int x,int y,char chr){
for(int i=0;i<=74;i++){
gotoRowCol(x,y);
cout<<chr;
y++;
}
}
int main()

{     int radius;
    cout<<"ENTER THE RADIUS: ";
    cin>>radius;
    int x=14,y=15;
    char chr='_';
    line(x,y,chr);


chr='*';
int c=20;

 while(c<80){
uper_wave(radius,c,chr);
c+=2*radius-1;
lower_wave(radius,c,chr);
c+=2*radius-1;
}


    getch();
    return 0;

}
