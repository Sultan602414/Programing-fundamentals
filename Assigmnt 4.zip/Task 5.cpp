#include <iostream>
#include<windows.h>
#include<math.h>
#include<conio.h>
using namespace std;
void sleep(int m){
for(int j=0;j<m*1300;j++){
}
}
void gotoRowCol(int rpos,int cpos){
int xpos=cpos,ypos=rpos;
COORD scrn;
HANDLE hOuput=GetStdHandle(STD_OUTPUT_HANDLE);
scrn.X=cpos;
scrn.Y=rpos;
SetConsoleCursorPosition(hOuput,scrn);
}

void circle(int radius,int r,int c,char chr){
double Q=1;

for(int i=Q ;i<=360;i++){
double x ,y;
x=radius*cos(3.14*2*Q/360) + r;
y=radius*sin(3.14*2*Q/360 )+ c ;
gotoRowCol(x,y);
cout<<chr;
Q++;

}
}
void eyes(int radius,int r,int c,char chr){
    double Q=1;
for(int i=Q ;i<=360;i++){
double x ,y;
x=radius*cos(3.14*2*Q/360) + r;
y=radius*sin(3.14*2*Q/360 )+ c ;
gotoRowCol(x,y);
cout<<chr;
Q++;
}
}
void sad(int radius,int r,int c,char chr){
 double Q=180;
for(int i=Q ;i<=360;i++){
double x ,y;
x=radius*cos(3.14*2*Q/360) + r;
y=radius*sin(3.14*2*Q/360 )+ c ;
gotoRowCol(y,x);
cout<<chr;
Q++;
}
}
void smile(int radius,int r,int c,char chr){
 double Q=1;
for(int i=Q ;i<=180;i++){
double x ,y;
x=radius*cos(3.14*2*Q/360) + r;
y=radius*sin(3.14*2*Q/360 )+ c ;
gotoRowCol(y,x);
cout<<chr;
Q++;

}
}
void shock (int radius,int r,int c ,int chr){
circle(radius,r,c ,chr );
}

int main()
{
double radius = 15;
char chr;
cout<<"ENTER THE CHARACTER: ";
cin>>chr;
int r=20,c=40;
circle(radius ,r,c, chr);
radius =1;
 r=15,c=33;
eyes(radius,r,c,chr);
c=46;
eyes(radius,r,c,chr);
r=40;c=23;radius=5;
//sad(radius,r,c,chr);
smile(radius,r,c,chr);
r=26,c=40;radius=4;
//shock(radius,r,c,chr);
getch();
    return 0;
}
