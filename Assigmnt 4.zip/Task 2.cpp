#include <iostream>
#include<windows.h>
#include<math.h>
#include<conio.h>
#include<random>
using namespace std;
void sleep(int m){
for(int j=0;j<m*8000;j++){
}
}
void gotoRowCol(int rpos,int cpos){
int xpos=cpos,ypos=rpos;
COORD scrn;
HANDLE hOuput=GetStdHandle(STD_OUTPUT_HANDLE);
scrn.X=cpos;
scrn.Y=rpos;
SetConsoleCursorPosition(hOuput,scrn);
}


void floors(char chr){
    for(int i=0;i<=10;i++){
    gotoRowCol(5,i);
    cout<<chr;
}
for(int i=10;i<85;i++){
    gotoRowCol(15,i);
    cout<<chr;
}
chr='|';
for(int i=6;i<20;i++){
     gotoRowCol(i,10);
    cout<<chr;
}}
void aadmi(char chr){
   for(int i=2;i<5;i++){
    gotoRowCol(i,5);
    cout<<chr;
   }
   gotoRowCol(5,6);
   cout<<chr;
   gotoRowCol(5,4);
   cout<<chr;
   gotoRowCol(3,4);
   cout<<chr;
   gotoRowCol(3,6);
   cout<<chr;
    gotoRowCol(2,7);
   cout<<chr;
   gotoRowCol(2,3);
   cout<<chr;
   chr='@';
   gotoRowCol(2,5);
   cout<<chr;
}
void stone(float x, float y, float slept,float times, char chr){

while(times>0){
int z=rand()%10+5;
     while(x<16){
     chr='*';
     gotoRowCol(x,y);
     cout<<chr;
     sleep(slept);
     chr=' ';
     gotoRowCol(x,y);
     cout<<chr;
     x=x+3;
     y=y+z;
     }
y=8;
x=3;


slept+=5000;
times--;


}}


int main(){
    char chr='_';
    floors(chr);
    chr='*';
    aadmi(chr);
    float times;
gotoRowCol(1,30);
cout<<"HOW MANY TIMES: ";
cin>>times;
float x=3,y=8,slept=18000;

stone(x,y,slept,times,chr);


    getch();
    return 0;
}
