#include <iostream>
#include<windows.h>
#include<math.h>
#include<conio.h>
using namespace std;
void sleep(int m){
for(int j=0;j<m*1300;j++){
}
}
void gotoRowCol(int rpos,int cpos){
int xpos=cpos,ypos=rpos;
COORD scrn;
HANDLE hOuput=GetStdHandle(STD_OUTPUT_HANDLE);
scrn.X=cpos;
scrn.Y=rpos;
SetConsoleCursorPosition(hOuput,scrn);
}

void circle(float radius,int r,int c,char chr){
double Q=1;
for(int i = 0;i<6;i++){
for(int i=Q ;i<360;i++){
double x,y;
x=radius*cos(3.14*2*Q/360) + r;
y=radius*sin(3.14*2*Q/360 )+ c ;
gotoRowCol(x,y);
Q+=1;

radius+=0.01;
sleep(200);
cout<<chr;
}
Q=1;
}
}
void rem_circle(float radius,int r,int c,char chr){
circle( radius, r, c, chr);
}
int main()
{   while(1){
    float radius=1;
    int r=25,c=55;
    char chr='*';

    circle(radius,r,c,chr);
    sleep(1000);
    chr=' ';
    rem_circle(radius,r,c,chr);
}
    getch();
    return 0;
}
