#include <iostream>
#include<windows.h>
#include<math.h>
#include<conio.h>
using namespace std;
void sleep(int m){
for(int j=0;j<m*13000;j++){
}
}
void gotoRowCol(int rpos,int cpos){
int xpos=cpos,ypos=rpos;
COORD scrn;
HANDLE hOuput=GetStdHandle(STD_OUTPUT_HANDLE);
scrn.X=cpos;
scrn.Y=rpos;
SetConsoleCursorPosition(hOuput,scrn);
}
void first_shape(int sr, int sc, int rdim,int cdim,char chr ){
    for(int i=sr;i<sr+cdim;i++){
        gotoRowCol(sr,i);
        cout<<chr;
    }
    for(int i=sr;i<sr+cdim;i++)
        {
         gotoRowCol(i,i);
        cout<<chr;
        }
     for(int i=sr;i<sr+cdim+1;i++){
        gotoRowCol(sr+cdim,i);
        cout<<chr;
    }
    for(int i=sr+cdim;i>=cdim;i--){
        gotoRowCol(i,sr++);
        cout<<chr;
    }

}
void second_shape(int sr,int sc,int rdim,int cdim,char chr){
for(int i=sr;i<sr+rdim;i++){
     gotoRowCol(i,2);

        cout<<chr;

}
for(int i=sr;i<sr+rdim;i++){
     gotoRowCol(i,40);

        cout<<chr;
} sr=0;
for(int i=20;i<sc+cdim;i++){
    gotoRowCol(i,sr=sr+4);

        cout<<chr;
}
sr=0;
for(int i=3*rdim-1;i>=2*rdim;i--){

    gotoRowCol(i,sr=sr+4);

        cout<<chr;
}
}
void rem_first(int sr,int sc,int rdim,int cdim,char chr){
 chr=' ';
first_shape(sr,sc,rdim,cdim,chr);
}
void rem_sec(int sr,int sc,int rdim,int cdim,char chr){
chr=' ';
second_shape(sr,sc,rdim,cdim,chr);
}
int main(){
    int  slept=10000;
    while(true){

    int sr=16, sc=10,rdim=10 ,cdim=16;
    char chr ='*';
    first_shape(sr,sc,rdim,cdim,chr);                                          // sr = cdim
    sleep(slept);
    rem_first(sr,sc,rdim,cdim,chr);
     sleep(slept);
    sr=20, sc=10,rdim=10 ,cdim=20;
    second_shape(sr,sc,rdim,cdim,chr);
    sleep(slept);
    rem_sec(sr,sc,rdim,cdim,chr);
    slept-=700;

}
getch();
    return 0;
}
