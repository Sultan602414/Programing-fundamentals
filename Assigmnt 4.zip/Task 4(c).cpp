#include <iostream>
#include<windows.h>
#include<math.h>
#include<conio.h>
using namespace std;
void sleep(int m){
for(int j=0;j<m*1300;j++){
}
}
void gotoRowCol(int rpos,int cpos){
int xpos=cpos,ypos=rpos;
COORD scrn;
HANDLE hOuput=GetStdHandle(STD_OUTPUT_HANDLE);
scrn.X=cpos;
scrn.Y=rpos;
SetConsoleCursorPosition(hOuput,scrn);
}

void circle(int radius,int r,int c,char chr){
double Q=1;

for(int i=Q ;i<=360;i++){
double x ,y;
x=radius*cos(3.14*2*Q/360) + r;
y=radius*sin(3.14*2*Q/360 )+ c ;
gotoRowCol(x,y);
cout<<chr;
Q++;
}
}
void uper_wave(int radius,int c,int slept,char chr){
    int n=1;
 double Q=-91;
 double x ,y;
while(Q>=-271){
    x=radius*cos(2*3.14*Q/360)+15;
	y=radius*sin(2*3.14*Q/360)+c;
		gotoRowCol(x,y);
        if(n==1){
            cout<<"S";
        }
        else if (n==2){
            cout<<"U";
        }
        else if (n==3){
            cout<<"L";
        }
            else if (n==4){
            cout<<"T";
        }
         else if (n==5){
            cout<<"A";
        }
         else if (n==6){
            cout<<"N";
        }
         else if(n==7) {
            n=0;
            Q=Q+16;
         }
         sleep(slept);
		 Q=Q-16;
         n++;
	}
}
void lower_wave(int radius,int c,int slept,char chr){
    int n=1;
    double x ,y;
 double Q=270;
while(Q<450){
x=radius*cos(3.14*2*Q/360) + 15;
y=radius*sin(3.14*2*Q/360 )+ c ;
gotoRowCol(x,y);
 if(n==1){
            cout<<"S";
        }
        else if (n==2){
            cout<<"U";
        }
        else if (n==3){
            cout<<"L";
        }
            else if (n==4){
            cout<<"T";
        }
         else if (n==5){
            cout<<"A";
        }
         else if (n==6){
            cout<<"N";
        }
         else if(n==7) {
            n=0;
            Q=Q-16;
         }
sleep(slept);
Q=Q+16;
n++;
}
}
void rem_upper(int radius,int c,char chr){
 chr=' ';
double Q=-91;
 double x ,y;
while(Q>=-271){
    x=radius*cos(2*3.14*Q/360)+15;
	y=radius*sin(2*3.14*Q/360)+c;
		gotoRowCol(x,y);
		cout<<chr;
		Q--;
}
}
void rem_lower(int radius,int c,char chr){
 chr=' ';
 double x ,y;
 double Q=270;
while(Q<450){
x=radius*cos(3.14*2*Q/360) + 15;
y=radius*sin(3.14*2*Q/360 )+ c;
gotoRowCol(x,y);
cout<<chr;
Q++;

}}

void line(int x,int y,char chr){
for(int i=0;i<=80;i++){
gotoRowCol(x,y);
cout<<chr;
y++;
}
}
int main()
{    while(true){
    int radius=5;
    int slept=9000,k=0;
    while(radius < 8){
    int x=14,y=15;
    char chr='_';
    line(x,y,chr);
chr='*';
int c=20;
 while(c<80){
uper_wave(radius,c,slept,chr);
c+=2*radius-1;
lower_wave(radius,c,slept,chr);
c+=2*radius-1;
 }

 c=20;

while(c<80){
 chr=' ';
rem_upper(radius,c,chr);
c=c+2*radius-1;
}
c=29+k;
 while(c<90){
 chr=' ';
rem_lower(radius,c,chr);
c=c+2*radius-1;
}


radius++;
k+=2;
  }
}
    getch();
    return 0;
}

