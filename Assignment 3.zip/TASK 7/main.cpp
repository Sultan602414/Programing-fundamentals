#include <iostream>

using namespace std;
float float_to_floor(float n){
    int x;
    if(n>0){
        x=n;
        cout<<x;
    }
    else if(n<0){
       x=n-1;
    cout<<x;
    return x;
}
}
int main()
{
    float y;
    cout<<"ENTER A NUMBER: ";
    cin>>y;
    float_to_floor(y);
    return 0;
}
