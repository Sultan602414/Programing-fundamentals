#include <iostream>

using namespace std;
char Symbol_Type(char n){

     if (n=='A'||n=='B'||n=='C'||n=='D'||n=='E'||n=='F'||n=='G'||n=='H'||n=='I'||n=='J'||n=='K'||n=='L'||n=='M'||n=='N'||n=='O'||n=='P'||n=='Q'||n=='R'||n=='S'||n=='T'||n=='U'||n=='V'||n=='W'||n=='X'||n=='Y'||n=='Z'){
    cout<<"Capital letter";
     }
      else if(n=='a'||n=='b'||n=='c'||n=='d'||n=='e'||n=='f'||n=='g'||n=='h'||n=='i'||n=='j'||n=='k'||n=='l'||n=='m'||n=='n'||n=='o'||n=='p'||n=='q'||n=='r'||n=='s'||n=='t'||n=='u'||n=='v'||n=='w'||n=='x'||n=='y'||n=='z'){
    cout<<"Small letter";
     }

     else{
        cout<<"Wrong character";
     }
     return n;
}
int main()
{
     char x;
     cout<<"ENtER A LETTER: ";
     cin>>x;
     Symbol_Type(x);

    return 0;
}
