#include <iostream>

using namespace std;
float float_to_cieling_int(float n){
    int x;
      x=n;
    if(n==x)
{
    cout<<x;
}
    else if(n>0){

    cout<<x+1<<endl;
}
    else if(n<0){
    cout<<x;
    return x;
}
}
int main()
{   float y;
    cout<<"ENTER A NUMBER: ";
    cin>>y;
    float_to_cieling_int(y);
    return 0;
}
