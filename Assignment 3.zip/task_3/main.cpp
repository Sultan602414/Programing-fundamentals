#include <iostream>
#include <cmath>
using namespace std;

int dist_form(int a,int b,int c,int d){
int result;
result = sqrt(pow(d - b, 2) + pow(c - a, 2));
return result;
}
int isrectangle(int a,int b,int c,int d){
    int x1,x2,x3,x4,y1,y2,y3,y4;
    int first_dist,sec_dist,third_dist,forth_dist,dignol_1,dignol_2;
    x1=a/10;
    y1=a%10;
    x2=b/10;
    y2=b%10;
    x3=c/10;
    y3=c%10;
    x4=d/10;
    y4=d%10;
first_dist=dist_form(x1,y1,x2,y2);
third_dist=dist_form(x1,y1,x3,y3);
sec_dist=dist_form(x3,y3,x4,y4);
forth_dist=dist_form(x2,y2,x4,y4);
dignol_1=dist_form(x1,y1,x4,y4);
dignol_2=dist_form(x2,y2,x3,y3);
if (first_dist==sec_dist && third_dist==forth_dist && sec_dist!=third_dist && dignol_1==dignol_2){
    cout<<" iTS A REctangle";
}
}
int issquare(int a,int b,int c,int d){
    int x1,x2,x3,x4,y1,y2,y3,y4;
    int first_dist,sec_dist,third_dist,forth_dist,dignol_1,dignol_2;
      x1=a/10;
    y1=a%10;
    x2=b/10;
    y2=b%10;
    x3=c/10;
    y3=c%10;
    x4=d/10;
    y4=d%10;
first_dist=dist_form(x1,y1,x2,y2);
third_dist=dist_form(x1,y1,x3,y3);
sec_dist=dist_form(x3,y3,x4,y4);
forth_dist=dist_form(x2,y2,x4,y4);
dignol_1=dist_form(x1,y1,x4,y4);
dignol_2=dist_form(x2,y2,x3,y3);
if(first_dist==sec_dist==third_dist==forth_dist && dignol_1==dignol_2){
    cout<<" iTS A SQUaRE";
}
}
int isparallelogram(int a,int b,int c,int d){
    int x1,x2,x3,x4,y1,y2,y3,y4;
    int first_dist,sec_dist,third_dist,forth_dist,dignol_1,dignol_2;
   x1=a/10;
    y1=a%10;
    x2=b/10;
    y2=b%10;
    x3=c/10;
    y3=c%10;
    x4=d/10;
    y4=d%10;
first_dist=dist_form(x1,y1,x2,y2);
third_dist=dist_form(x1,y1,x3,y3);
sec_dist=dist_form(x3,y3,x4,y4);
forth_dist=dist_form(x2,y2,x4,y4);
dignol_1=dist_form(x1,y1,x4,y4);
dignol_2=dist_form(x2,y2,x3,y3);
if (first_dist==sec_dist && third_dist!=forth_dist && dignol_1==dignol_2){
    cout<<" iTS A parallelogram";
}
}
int isrhombus(int a,int b,int c,int d){
    int x1,x2,x3,x4,y1,y2,y3,y4;
    int first_dist,sec_dist,third_dist,forth_dist,dignol_1,dignol_2;
   x1=a/10;
    y1=a%10;
    x2=b/10;
    y2=b%10;
    x3=c/10;
    y3=c%10;
    x4=d/10;
    y4=d%10;
first_dist=dist_form(x1,y1,x2,y2);
third_dist=dist_form(x1,y1,x3,y3);
sec_dist=dist_form(x3,y3,x4,y4);
forth_dist=dist_form(x2,y2,x4,y4);
dignol_1=dist_form(x1,y1,x4,y4);
dignol_2=dist_form(x2,y2,x3,y3);
if(first_dist==sec_dist==third_dist==forth_dist && dignol_1!=dignol_2){
    cout<<" iTS A rhombus";
}
}
int main()
{
    int a,b,c,d;
    cout<<"ENTER NUMBER: ";
    cin>>a>>b>>c>>d;
    isrectangle(a,b,c,d);
    issquare(a,b,c,d);
    isrhombus(a,b,c,d);
    isparallelogram(a,b,c,d);

    return 0;
}
