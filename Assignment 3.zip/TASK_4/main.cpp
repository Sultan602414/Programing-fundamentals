#include<iostream>
#include<cmath>
using namespace std;

void equilateral(int x1,int y1,int x2,int y2,int x3,int y3)
{
	int s1,s2,s3;
		s1=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
		s2=sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
	    s3=sqrt((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3));
		if (s1==s2 && s2==s3 && s1==s3)
		{
			cout<<"THIS IS Equilateral Triangle";
		}
}
void isosceles(int x1,int y1,int x2,int y2,int x3,int y3)
{
	int s1,s2,s3;
		s1=((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
		s2=((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
	    s3=((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3));
	    if (((s1==s2 && s1!=s3) || (s2==s3 && s2!=s1) || (s1==s3 && s1!=s2)) && ((s1 != s2 + s3) && (s2 != s1 + s3) && (s3 != s1 + s2)))
	    {
	    	cout<<" THIS IS Isosceles Triangle";
		}
}

void right_angle(int x1,int y1,int x2,int y2,int x3,int y3)
{
	int s1,s2,s3;
		s1 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
		s2 = (x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2);
		s3 = (x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3);

		if ((s1 == s2 + s3) || (s2 == s1 + s3) || (s3 == s1 + s2))

		{
			cout<<" THIS IS Right Angle Triangle";
		}
}

void scalene(int x1,int y1,int x2,int y2,int x3,int y3)
{
	int s1,s2,s3;
		s1 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
		s2 = (x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2);
		s3 = (x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3);
		if(s1!=s2 && s2!=s3 && s1!=s3 && ((s1 != s2 + s3) && (s2 != s1 + s3) && (s3 != s1 + s2)))
		{
			cout<<" THIS IS Scalene Triangle";
		}
}
int main()
{
	int x1,y1,x2,y2,x3,y3;
	cout<<"ENTER FIRST POINT(x1,y1): ";
	cin>>x1>>y1;
	cout<<"ENTER second POINT(x2,y2): ";
	cin>>x2>>y2;
	cout<<"ENTER third POINT(x3,y3): ";
	cin>>x3>>y3;
	equilateral(x1,y1,x2,y2,x3,y3);
	right_angle(x1,y1,x2,y2,x3,y3);
	isosceles(x1,y1,x2,y2,x3,y3);
	scalene(x1,y1,x2,y2,x3,y3);
     return 0;

}
