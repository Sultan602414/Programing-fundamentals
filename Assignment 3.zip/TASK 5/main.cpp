#include<iostream>
#include<cmath>
using namespace std;

int rectangle(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4,int px, int py)
{
	int s1,s2,s3,s4,d1,d2;

		s1=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
		s2=sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
	    s3=sqrt((x4-x3)*(x4-x3)+(y4-y3)*(y4-y3));
		s4=sqrt((x1-x4)*(x1-x4)+(y1-y4)*(y1-y4));
		d1=sqrt((x3-x1)*(x3-x1)+(y3-y1)*(y3-y1));
		d2=sqrt((x4-x2)*(x4-x2)+(y4-y2)*(y4-y2));

		if(s1==s3 && s2==s4 && s1!=s2 && s2!=s3  && d1==d2)
		{
			cout<<"Rectangle"<<endl;
			if (px>x1 && px<x3 && py>y1 && py<y3)
			{
				cout<<"inside";
			}
			else if ((px==x1 || px==x2 || px==x3 || px==x4) && (py==y1 || py==y2 || py==y3 || py==y4))
			{
				cout<<"lies on the rectangle";
			}
			else
			{
				cout<<"Outside the rectangle";
			}
		}
}
int main()
{
	int x1,y1,x2,y2,x3,y3,x4,y4,px,py;
	cout<<"ENTER first POINT(x1,y1) ";
	cin>>x1>>y1;
	cout<<"ENTER second POINT(x2,y2) ";
	cin>>x2>>y2;
	cout<<"ENTER third POINT(x3,y3) ";
	cin>>x3>>y3;
	cout<<"ENTER forth POINT(x4,y4)";
	cin>>x4>>y4;
	cout<<"ENTER  POINT(x,y)";
	cin>>px>>py;

	rectangle(x1,y1,x2,y2,x3,y3,x4,y4,px,py);

	return 0;
}
