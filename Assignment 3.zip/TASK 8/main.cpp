#include <iostream>
#include <cmath>
using namespace std;
int count(int num){
    int x=0;
while (num!=0){

    num=num/10;
    x=x+1;
}
return x-1;
}

int digit_to_words(int a, int b){
int num2,digit;
for(int i=b;b!=-1;b--){
    num2=a/pow(10,b);
    digit=num2%10;
    switch(digit){
    case 0:
        cout<<" Zero ";
        break;
    case 1:
        cout<<" One ";
        break;
    case 2:
        cout<<" Two ";
        break;
    case 3:
        cout<<" Three ";
        break;
    case 4:
        cout<<" Four ";
        break;
    case 5:
        cout<<" Five ";
        break;
    case 6:
        cout<<" Six ";
        break;
    case 7:
        cout<<" Seven ";
        break;
    case 8:
        cout<<" Eight ";
        break;
    case 9:
        cout<<" Nine ";
        break;
    }

}
return num2;
}
char Symbol_Type(char n){

     if (n=='A'||n=='B'||n=='C'||n=='D'||n=='E'||n=='F'||n=='G'||n=='H'||n=='I'||n=='J'||n=='K'||n=='L'||n=='M'||n=='N'||n=='O'||n=='P'||n=='Q'||n=='R'||n=='S'||n=='T'||n=='U'||n=='V'||n=='W'||n=='X'||n=='Y'||n=='Z'){
    cout<<"Capital letter"<<endl;
     }
      else if(n=='a'||n=='b'||n=='c'||n=='d'||n=='e'||n=='f'||n=='g'||n=='h'||n=='i'||n=='j'||n=='k'||n=='l'||n=='m'||n=='n'||n=='o'||n=='p'||n=='q'||n=='r'||n=='s'||n=='t'||n=='u'||n=='v'||n=='w'||n=='x'||n=='y'||n=='z'){
    cout<<"Small letter"<<endl;
     }

     else{
        cout<<"Wrong character"<<endl;
     }
     return n;
}

int dist_form(int a,int b,int c,int d){
int result;
result = sqrt(pow(d - b, 2) + pow(c - a, 2));
return result;
}
int isrectangle(int a,int b,int c,int d){
    int x1,x2,x3,x4,y1,y2,y3,y4;
    int first_dist,sec_dist,third_dist,forth_dist,dignol_1,dignol_2;
    x1=a/10;
    y1=a%10;
    x2=b/10;
    y2=b%10;
    x3=c/10;
    y3=c%10;
    x4=d/10;
    y4=d%10;
first_dist=dist_form(x1,y1,x2,y2);
third_dist=dist_form(x1,y1,x3,y3);
sec_dist=dist_form(x3,y3,x4,y4);
forth_dist=dist_form(x2,y2,x4,y4);
dignol_1=dist_form(x1,y1,x4,y4);
dignol_2=dist_form(x2,y2,x3,y3);
if (first_dist==sec_dist && third_dist==forth_dist && sec_dist!=third_dist && dignol_1==dignol_2){
    cout<<" iTS A REctangle"<<endl;
}
}
int issquare(int a,int b,int c,int d){
    int x1,x2,x3,x4,y1,y2,y3,y4;
    int first_dist,sec_dist,third_dist,forth_dist,dignol_1,dignol_2;
      x1=a/10;
    y1=a%10;
    x2=b/10;
    y2=b%10;
    x3=c/10;
    y3=c%10;
    x4=d/10;
    y4=d%10;
first_dist=dist_form(x1,y1,x2,y2);
third_dist=dist_form(x1,y1,x3,y3);
sec_dist=dist_form(x3,y3,x4,y4);
forth_dist=dist_form(x2,y2,x4,y4);
dignol_1=dist_form(x1,y1,x4,y4);
dignol_2=dist_form(x2,y2,x3,y3);
if(first_dist==sec_dist==third_dist==forth_dist && dignol_1==dignol_2){
    cout<<" iTS A SQUaRE"<<endl;
}
}
int isparallelogram(int a,int b,int c,int d){
    int x1,x2,x3,x4,y1,y2,y3,y4;
    int first_dist,sec_dist,third_dist,forth_dist,dignol_1,dignol_2;
   x1=a/10;
    y1=a%10;
    x2=b/10;
    y2=b%10;
    x3=c/10;
    y3=c%10;
    x4=d/10;
    y4=d%10;
first_dist=dist_form(x1,y1,x2,y2);
third_dist=dist_form(x1,y1,x3,y3);
sec_dist=dist_form(x3,y3,x4,y4);
forth_dist=dist_form(x2,y2,x4,y4);
dignol_1=dist_form(x1,y1,x4,y4);
dignol_2=dist_form(x2,y2,x3,y3);
if (first_dist==sec_dist && third_dist!=forth_dist && dignol_1==dignol_2){
    cout<<" iTS A parallelogram"<<endl;
}
}
int isrhombus(int a,int b,int c,int d){
    int x1,x2,x3,x4,y1,y2,y3,y4;
    int first_dist,sec_dist,third_dist,forth_dist,dignol_1,dignol_2;
   x1=a/10;
    y1=a%10;
    x2=b/10;
    y2=b%10;
    x3=c/10;
    y3=c%10;
    x4=d/10;
    y4=d%10;
first_dist=dist_form(x1,y1,x2,y2);
third_dist=dist_form(x1,y1,x3,y3);
sec_dist=dist_form(x3,y3,x4,y4);
forth_dist=dist_form(x2,y2,x4,y4);
dignol_1=dist_form(x1,y1,x4,y4);
dignol_2=dist_form(x2,y2,x3,y3);
if(first_dist==sec_dist==third_dist==forth_dist && dignol_1!=dignol_2){
    cout<<" iTS A rhombus"<<endl;
}
}

void equilateral(int x1,int y1,int x2,int y2,int x3,int y3)
{
	int s1,s2,s3;
		s1=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
		s2=sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
	    s3=sqrt((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3));
		if (s1==s2 && s2==s3 && s1==s3)
		{
			cout<<"THIS IS Equilateral Triangle"<<endl;
		}
}
void isosceles(int x1,int y1,int x2,int y2,int x3,int y3)
{
	int s1,s2,s3;
		s1=((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
		s2=((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
	    s3=((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3));
	    if (((s1==s2&&s1!=s3)||(s2==s3&&s2!=s1)||(s1==s3&&s1!=s2))&&((s1!=s2+s3)&&(s2!=s1+s3)&&(s3!=s1+s2)))
	    {
	    	cout<<" THIS IS Isosceles Triangle"<<endl;
		}
}

void right_angle(int x1,int y1,int x2,int y2,int x3,int y3)
{
	int s1,s2,s3;
		s1=(x2-x1)*(x2-x1)+(y2-y1)*(y2-y1);
		s2=(x3-x2)*(x3-x2)+(y3-y2)*(y3-y2);
		s3=(x1-x3)*(x1-x3)+(y1-y3)*(y1-y3);

		if ((s1==s2+s3)||(s2==s1+s3)||(s3==s1+s2))

		{
			cout<<" THIS IS Right Angle Triangle"<<endl();
		}
}

void scalene(int x1,int y1,int x2,int y2,int x3,int y3)
{
	int s1,s2,s3;
		s1=(x2-x1)*(x2-x1)+(y2-y1)*(y2-y1);
		s2=(x3-x2)*(x3-x2)+(y3-y2)*(y3 - y2);
		s3=(x1-x3)*(x1-x3)+(y1-y3)*(y1 - y3);
		if(s1!=s2 && s2!=s3 && s1!=s3 && ((s1!=s2+s3) && (s2!=s1+s3) && (s3!=s1+s2)))
		{
			cout<<" THIS IS Scalene Triangle";
		}
}
int rectangle(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4,int px, int py)
{
	int s1,s2,s3,s4,d1,d2;

		s1=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
		s2=sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
	    s3=sqrt((x4-x3)*(x4-x3)+(y4-y3)*(y4-y3));
		s4=sqrt((x1-x4)*(x1-x4)+(y1-y4)*(y1-y4));
		d1=sqrt((x3-x1)*(x3-x1)+(y3-y1)*(y3-y1));
		d2=sqrt((x4-x2)*(x4-x2)+(y4-y2)*(y4-y2));

		if(s1==s3 && s2==s4 && s1!=s2 && s2!=s3  && d1==d2)
		{
			cout<<"Rectangle"<<endl;
			if (px>x1 && px<x3 && py>y1 && py<y3)
			{
				cout<<"inside";
			}
			else if ((px==x1 || px==x2 || px==x3 || px==x4) && (py==y1 || py==y2 || py==y3 || py==y4))
			{
				cout<<"lies on the rectangle";
			}
			else
			{
				cout<<"Outside the rectangle";
			}
		}
}

float float_to_cieling_int(float n){
    int x;
      x=n;
    if(n==x)
{
    cout<<x;
}
    else if(n>0){

    cout<<x+1<<endl;
}
    else if(n<0){
    cout<<x;
    return x;
}
}
float float_to_floor(float n){
    int x;
    if(n>0){
        x=n;
        cout<<x;
    }
    else if(n<0){
       x=n-1;
    cout<<x;
    return x;
}
}

int main()
{
    float y;
int num,digits;
	cout<<"Please enter your number: ";
	cin>>num;

	digits=count(num);

	if(digits<=5)
	{
	y=digit_to_words(num,digits);
	}
	else
	{
		cout<<"Wrong input";
	}


	char x;
     cout<<"ENtER A LETTER: ";
     cin>>x;
     Symbol_Type(x);




    int a,b,c,d;
    cout<<"ENTER NUMBER: ";
    cin>>a>>b>>c>>d;
    isrectangle(a,b,c,d);
    issquare(a,b,c,d);
    isrhombus(a,b,c,d);
    isparallelogram(a,b,c,d);




    int x1,y1,x2,y2,x3,y3;
	cout<<"ENTER FIRST POINT(x1,y1): ";
	cin>>x1>>y1;
	cout<<"ENTER second POINT(x2,y2): ";
	cin>>x2>>y2;
	cout<<"ENTER third POINT(x3,y3): ";
	cin>>x3>>y3;
	equilateral(x1,y1,x2,y2,x3,y3);
	right_angle(x1,y1,x2,y2,x3,y3);
	isosceles(x1,y1,x2,y2,x3,y3);
	scalene(x1,y1,x2,y2,x3,y3);



	int px,py,x4,y4;
	cout<<"ENTER first POINT(x1,y1) ";
	cin>>x1>>y1;
	cout<<"ENTER second POINT(x2,y2) ";
	cin>>x2>>y2;
	cout<<"ENTER third POINT(x3,y3) ";
	cin>>x3>>y3;
	cout<<"ENTER forth POINT(x4,y4)";
	cin>>x4>>y4;
	cout<<"ENTER  POINT(x,y)";
	cin>>px>>py;

	rectangle(x1,y1,x2,y2,x3,y3,x4,y4,px,py);



    cout<<"ENTER A NUMBER: ";
    cin>>y;
    float_to_cieling_int(y);



    cout<<"ENTER A NUMBER: ";
    cin>>y;
    float_to_floor(y);



    return 0;
}
