#include <iostream>
#include <cmath>
using namespace std;
int count(int num){
    int x=0;
while (num!=0){

    num=num/10;
    x=x+1;
}
return x-1;
}

int digit_to_words(int a, int b){
int num2,digit;
for(int i=b;b!=-1;b--){
    num2=a/pow(10,b);
    digit=num2%10;
    switch(digit){
    case 0:
        cout<<" Zero ";
        break;
    case 1:
        cout<<" One ";
        break;
    case 2:
        cout<<" Two ";
        break;
    case 3:
        cout<<" Three ";
        break;
    case 4:
        cout<<" Four ";
        break;
    case 5:
        cout<<" Five ";
        break;
    case 6:
        cout<<" Six ";
        break;
    case 7:
        cout<<" Seven ";
        break;
    case 8:
        cout<<" Eight ";
        break;
    case 9:
        cout<<" Nine ";
        break;
    }

}
return num2;

}

int main()
{
	int num,y,digits;
	cout<<"Please enter your number: ";
	cin>>num;

	digits=count(num);

	if(digits<=5)
	{
	y=digit_to_words(num,digits);
	}
	else
	{
		cout<<"Wrong input";
	}
	return 0;
}


