#include <iostream>

using namespace std;
void increment (double & x){
int z=1;
while(x!=-1){
    cin>>x;
    if(x!=-1){


    cout<<z<<endl;
    z=z+1;
}
else{
    break;
}
}

}
int main()
{
    double n;
   increment(n);

    return 0;
}
