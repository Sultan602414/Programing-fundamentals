#include <iostream>

using namespace std;
void swaping(double & x,double & y){
    double z ;
z=x;
x=y;
y=z;
}
int main()
{
   double a,b;
   cout<<"ENTER TWO NUMBERS YOU WANT TO SWAAP: " ;
   cin>>a>>b;
   cout<<"BEFORE SWAPING: a="<<a<<" and b="<<b<<endl;
   swaping(a,b);
   cout<<"AFTER SWAPING: a="<<a<<" and b="<<b;
    return 0;
}
