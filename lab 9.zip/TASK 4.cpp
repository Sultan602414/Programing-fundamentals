#include<iostream>
using namespace std;

void revers(int n1, int & n2)
{
	int num;
	while(n1!=0)
{
    num=n1%10;
    n2=n2*10 + num;
    n1=n1/10;
}
}
void palindrom(int n1 ,int  n2){

if (n1==n2){
    cout<<"ITS A PALLINDROME: ";
}
else{
     cout<<"ITS NOT A PALLINDROME: ";
}
}
int main()
{ int x, y=0;
	cin>>x;
	revers(x,y);
	cout<<"Your number reverse value is: "<<y<<endl;
	palindrom(x,y);
    return 0;
}
