#include <iostream>

using namespace std;
void factorial(int & a,int & fact){
 fact=1;
 cin>>a;
for(int i=a;i>0;i--){
    fact=fact*i;
   }
}
int main()
{   int a,b;
    factorial(a,b);
    cout<<b;
    return 0;
}
