#include <iostream>

using namespace std;

void maxmin(int & num,int & maxx,int & minn,int & sec_max,int & sec_min){

    cin>>num;
    maxx=num;
    minn=num;
    sec_max=num;
    sec_min=num;
    while(num!=-1){
    cin>>num;

    if(num!=-1){

    if (num> maxx){
        maxx=num;
    }
    else{
        maxx=maxx;
    }
    if (num<minn){
        minn=num;
    }else {
    minn=minn;
    }
    if (num>sec_max && num<maxx){
       sec_max=num;
    }else{
    sec_max=sec_max;
    }
    if (num<sec_min  && num>minn){
        sec_min=num;
    }else{
    sec_min=sec_min;
    }
}
else{
break;
}
}
}
int main()
{
    int  a,  b,  c,d,e  ;
maxmin(a,b,c,d,e);

cout<<"THE MAX NO IS: "<<b<<endl;
cout<<"THE min NO IS: "<<c<<endl;
cout<<"THE SECOND MAX NO IS: "<<d<<endl;
cout<<"THE SECOND MIN NO IS: "<<e<<endl;
    return 0;
}
