#include<iostream>
#include<windows.h>
#include<conio.h>
#include<math.h>
#include<fstream>

// task 1
struct persons{
string name;
int age;
string address;
};

int main()
{

     // TASk 1
     persons person_1;
     cout<<"ENTER THE NAME: ";
     cin>>person_1.name;
     cout<<"ENTER THE AGE: ";
     cin>>person_1.age;
     cout<<"ENTER THE Address: ";
     cin>>person_1.address;
    cout<<person_1.name<<" of age "<<person_1.age<<" Years"<< " has address "<<person_1.address;




    return 0;
}
