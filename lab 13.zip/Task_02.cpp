#include<iostream>
#include<windows.h>
#include<conio.h>
#include<math.h>
#include<fstream>
using namespace std;
void gotoRowCol(int rpos, int cpos)
{
	int xpos=cpos, ypos = rpos;
	COORD scrn;
	HANDLE hOuput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = cpos;
	scrn.Y = rpos;
	SetConsoleCursorPosition(hOuput, scrn);
}
void sleep(float time)
{
    int limit = time * 500000000;
    for (int i=0; i<=limit; i++)
    {
    }
}
void printSBox(int row, int col, int rdim, int cdim, char ch)
{
    int r=row, c=col;
    while(c<=cdim)
    {
        gotoRowCol(r,c);
        cout << ch;
        c++;
    }
    while(r<=rdim)
    {
        gotoRowCol(r,c);
        cout << ch;
        r++;
    }
    while(c>=col)
    {
        gotoRowCol(r,c);
        cout<< ch;
        c--;
    }
    while(r>=row)
    {
        gotoRowCol(r,c);
        cout << ch;
        r--;
    }
}
void printBox(int row, int col, int rdim, int cdim, char ch)
{
    int r=row, c=col, rd=rdim, cd=cdim;
    for(int i=1; i<=8; i++)
    {
        for(int j=1; j<=8; j++)
        {
            gotoRowCol(r,c);
            printSBox(row, col, rdim, cdim, ch);
            c+=cd;
            cdim+=cd;
        }
        c=col;
        cdim=cd;
        row+=rd+1;
        rdim+=rd+1;
    }
}
void printNumber(int row, int col, int rdim, int cdim)
{
    int r=row+1, c=col+1, rd=rdim, cd=cdim;
    for(int i=1; i<=8; i++)
    {
        char ch=104;
        for(int j=1; j<=8; j++)
        {
            gotoRowCol(r,c);
            cout << ch << i;
            ch--;
            c+=cd;
            cdim+=cd;
        }
        c=col+1;
        cdim=cd;
        r+=rd+1;
        rdim+=rd+1;
    }
}
void initPP1(char A[])
{
    A[0]='R';
    A[1]='N';
    A[2]='B';
    A[3]='K';
    A[4]='Q';
    A[5]='B';
    A[6]='N';
    A[7]='R';
    A[8]='P';
    A[9]='P';
    A[10]='P';
    A[11]='P';
    A[12]='P';
    A[13]='P';
    A[14]='P';
    A[15]='P';
}
void initPP2(char A[])
{
    A[0]='p';
    A[1]='p';
    A[2]='p';
    A[3]='p';
    A[4]='p';
    A[5]='p';
    A[6]='p';
    A[7]='p';
    A[8]='r';
    A[9]='n';
    A[10]='b';
    A[11]='k';
    A[12]='q';
    A[13]='b';
    A[14]='n';
    A[15]='r';
}
void PrintP(char A[], int len, int row , int col, int rdim, int cdim)
{
    int r=row+2, cd=cdim, rd=rdim, c=col+5; row=row+2, col=col+5;
    for(int i=0; i<len; i++)
    {
        gotoRowCol(row,col);
        cout << A[i];
        col += cd;
        cdim+= cd;
        if (i%8==7)
        {
            row+=rd+1;
            rdim+=rd+1;
            col=c;
            cdim=cd;
        }
    }
}
void printBoard(int row, int col, int rdim, int cdim, char ch, char A[], char B[])
{
    printBox(row,col,rdim,cdim,ch);
    printNumber(row, col, rdim, cdim);
    PrintP(A, 16, row, col, rdim, cdim);
    PrintP(B, 16, 6*rdim+6, col, rdim, cdim);
}
void writer(char A[], int len, string file)
{
    ofstream W(file);
    for(int i=0; i<=len; i++)
    {
            W << A[i] << "  ";
    }
}
void reader(char A[], int len, string file)
{
    ifstream R(file);
    for (int i=0; i<=len; i++)
    {
        R >> A[i];
    }
}
int main()
{
    int row=0, col=1, rdim=4, cdim=10;
    char ch=219;
    char Player_1[16], Player_2[16], ask ;
    cout << "Press (S) for starting a new game or press (L) to load previous game";
    ask=getch();
    if (ask=='S' || ask=='s')
    {
        initPP1(Player_1);
        initPP2(Player_2);
    }
    else if(ask=='L' || ask=='l')
    {
        reader(Player_1, 16, "Player1.txt" );
        reader(Player_2, 16, "Player2.txt");
    }
    system("CLS");
    printBoard(row,col,rdim,cdim,ch,Player_1,Player_2);
    writer(Player_1, 16, "Player1.txt");
    writer(Player_2, 16, "Player2.txt");
    getch();

    return 0;
}
